import React from "react";

const ResourcesPag = () => {
  return <div>ResourcesPag</div>;
};

export default ResourcesPag;
