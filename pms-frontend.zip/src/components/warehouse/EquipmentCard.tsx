import React from 'react'

const EquipmentCard = () => {
  return (
    <div>EquipmentCard</div>
  )
}

export default EquipmentCard